export interface Heroe{
 nombre:string;
 bio:string;
 img:string;
 aparicion:string;
 casa:string;
}